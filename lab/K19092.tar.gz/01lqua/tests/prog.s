	.globl main
main:
    pushq %rbp
    movq %rsp, %rbp
    subq $32, %rsp
    callq input_int
    movq %rax, -8(%rbp)
    movq $1, %rax
    negq %rax
    movq %rax, -16(%rbp)
    movq -8(%rbp), %rax
    subq -16(%rbp), %rax
    movq %rax, -24(%rbp)
    movq -24(%rbp), %rdi
    callq print_int
    movq %rbp, %rsp
    movq $0, %rax
    popq %rbp
    retq 


